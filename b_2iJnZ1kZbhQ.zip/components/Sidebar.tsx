'use client'

import { BarChart3, Calendar, FileText, Settings, Slack, Home, Plus } from 'lucide-react'

const navItems = [
  { icon: Home, label: 'Dashboard', active: true },
  { icon: Calendar, label: 'Calendar' },
  { icon: FileText, label: 'My Tasks' },
  { icon: BarChart3, label: 'Statistics' },
  { icon: FileText, label: 'Documents' },
]

const integrations = [
  { icon: Slack, label: 'Slack' },
  { icon: Home, label: 'Notion' },
  { icon: Plus, label: 'Add new plugin' },
]

const teams = [
  { initials: 'SE', label: 'SEO', color: 'bg-slate-700' },
  { initials: 'M', label: 'Marketing', color: 'bg-slate-600' },
]

export function Sidebar() {
  return (
    <aside className="w-40 bg-white dark:bg-slate-900 border-r border-gray-200 dark:border-slate-700 flex flex-col p-4 h-screen">
      {/* Logo */}
      <div className="flex items-center gap-2 mb-8">
        <div className="w-8 h-8 bg-black dark:bg-white rounded flex items-center justify-center">
          <span className="text-white dark:text-black font-bold text-sm">#</span>
        </div>
        <span className="font-semibold text-gray-900 dark:text-white">iDraft</span>
      </div>

      {/* Navigation */}
      <nav className="space-y-1 mb-6">
        {navItems.map((item, idx) => {
          const Icon = item.icon
          return (
            <button
              key={idx}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition ${
                item.active
                  ? 'bg-black dark:bg-slate-700 text-white'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{item.label}</span>
            </button>
          )
        })}
      </nav>

      {/* Integrations Section */}
      <div className="mb-6">
        <p className="text-xs uppercase font-semibold text-gray-500 dark:text-gray-400 mb-3">
          Integrations
        </p>
        <nav className="space-y-1">
          {integrations.map((item, idx) => {
            const Icon = item.icon
            return (
              <button
                key={idx}
                className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-800 transition"
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            )
          })}
        </nav>
      </div>

      {/* Teams Section */}
      <div className="mb-6">
        <p className="text-xs uppercase font-semibold text-gray-500 dark:text-gray-400 mb-3">
          Teams
        </p>
        <div className="space-y-2">
          {teams.map((team, idx) => (
            <button
              key={idx}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-800 transition"
            >
              <div className={`w-6 h-6 rounded-full ${team.color} flex items-center justify-center text-white text-xs font-bold`}>
                {team.initials}
              </div>
              <span>{team.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Settings - Bottom */}
      <div className="mt-auto">
        <button className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-800 transition">
          <Settings className="w-4 h-4" />
          <span>Settings</span>
        </button>
      </div>
    </aside>
  )
}
