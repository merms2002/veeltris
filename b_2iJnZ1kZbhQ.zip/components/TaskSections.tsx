'use client'

import { Gift, DollarSign, Lock, Edit, MoreVertical, ChevronRight } from 'lucide-react'

export function TaskSections() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
      {/* Month goals */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-gray-200 dark:border-slate-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Month goals:
        </h3>

        <div className="space-y-3">
          {[
            { label: 'Read 2 books', checked: true },
            { label: 'Sports every day', checked: false },
            { label: 'Complete the course', checked: false },
            { label: 'Build down with a pancake', checked: false },
          ].map((goal, idx) => (
            <div key={idx} className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={goal.checked}
                readOnly
                className="w-5 h-5 mt-0.5 rounded border-gray-300 dark:border-slate-600 accent-blue-500"
              />
              <label className={`text-sm ${goal.checked ? 'text-gray-400 dark:text-gray-500 line-through' : 'text-gray-700 dark:text-gray-300'}`}>
                {goal.label}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Task in process */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-gray-200 dark:border-slate-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Task in process (2)
        </h3>

        <div className="space-y-4">
          {[
            { icon: Gift, label: 'Buy Dilan a gift for Birthday', time: 'Today', color: 'bg-purple-100 dark:bg-purple-900/30' },
            { icon: DollarSign, label: "Doctor's appointment on Tuesday", time: '02/09/2023', color: 'bg-emerald-100 dark:bg-emerald-900/30' },
          ].map((task, idx) => (
            <div
              key={idx}
              className="bg-gray-50 dark:bg-slate-800 rounded-lg p-4 hover:bg-gray-100 dark:hover:bg-slate-700 transition cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded ${task.color}`}>
                  <task.icon className="w-5 h-5 text-gray-700 dark:text-gray-300" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                    {task.label}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{task.time}</p>
                </div>
                <button className="p-1 hover:bg-gray-200 dark:hover:bg-slate-600 rounded transition">
                  <Lock className="w-4 h-4 text-gray-400 dark:text-gray-500" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right column with drawer and archive */}
      <div className="space-y-4">
        {/* Add task drawer */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-gray-200 dark:border-slate-700 h-32 flex flex-col items-center justify-center hover:bg-gray-50 dark:hover:bg-slate-800/50 transition cursor-pointer">
          <div className="text-center">
            <div className="text-3xl text-gray-300 dark:text-gray-600 mb-2">+</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">Add task</p>
          </div>
        </div>

        {/* Open archive */}
        <div className="bg-gray-100 dark:bg-slate-800 rounded-2xl p-6 border border-gray-200 dark:border-slate-700 hover:bg-gray-200 dark:hover:bg-slate-700 transition cursor-pointer">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
              Open archive
            </p>
            <ChevronRight className="w-4 h-4 text-gray-500 dark:text-gray-400" />
          </div>
        </div>
      </div>
    </div>
  )
}
