'use client'

import { Share2, MoreVertical } from 'lucide-react'

export function OverallInfoCard() {
  const stats = [
    { value: '43', label: 'Task done\nthis month', icon: '✓' },
    { value: '2', label: 'Projects on\ngoing', icon: '→' },
  ]

  const details = [
    { label: 'In Progress', value: '28' },
    { label: 'In Progress', value: '14' },
    { label: 'Completed', value: '11' },
  ]

  return (
    <div className="bg-gray-900 dark:bg-slate-800 rounded-2xl p-6 text-white mb-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Overall information</h3>
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-gray-800 dark:hover:bg-slate-700 rounded-lg transition">
            <Share2 className="w-4 h-4" />
          </button>
          <button className="p-2 hover:bg-gray-800 dark:hover:bg-slate-700 rounded-lg transition">
            <MoreVertical className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        {stats.map((stat, idx) => (
          <div key={idx} className="flex items-baseline gap-3">
            <div className="text-3xl font-bold">{stat.value}</div>
            <div className="text-sm text-gray-400 leading-tight">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="flex gap-4 justify-between">
        {details.map((detail, idx) => (
          <div
            key={idx}
            className="bg-gray-800 dark:bg-slate-700 rounded-xl p-4 flex-1 text-center hover:bg-gray-700 dark:hover:bg-slate-600 transition cursor-pointer"
          >
            <div className="text-gray-400 text-xs uppercase mb-2">{detail.label}</div>
            <div className="text-3xl font-bold">{detail.value}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
