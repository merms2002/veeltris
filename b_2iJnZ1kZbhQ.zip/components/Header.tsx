'use client'

import { Search, Bell, Moon, Sun, Plus, User } from 'lucide-react'
import { useTheme } from './ThemeProvider'

export function Header() {
  const { theme, toggleTheme } = useTheme()

  return (
    <header className="bg-white dark:bg-slate-900 border-b border-gray-200 dark:border-slate-700 px-8 py-4 flex items-center justify-between">
      <div className="flex-1">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">
          Hi, Dilan!
        </h1>
      </div>

      <div className="flex items-center gap-4">
        {/* Search */}
        <div className="hidden sm:flex items-center gap-2 bg-gray-100 dark:bg-slate-800 rounded-lg px-3 py-2">
          <Search className="w-4 h-4 text-gray-500 dark:text-gray-400" />
          <input
            type="text"
            placeholder="Search..."
            className="bg-transparent border-none outline-none text-sm text-gray-700 dark:text-gray-300 placeholder-gray-500 dark:placeholder-gray-400"
          />
        </div>

        {/* Create Button */}
        <button className="hidden sm:flex items-center gap-2 bg-black dark:bg-slate-700 text-white px-3 py-2 rounded-lg hover:bg-gray-900 dark:hover:bg-slate-600 transition text-sm font-medium">
          <Plus className="w-4 h-4" />
          Create
        </button>

        {/* Icons */}
        <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg transition">
          <Search className="w-5 h-5 text-gray-600 dark:text-gray-300" />
        </button>

        <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg transition relative">
          <Bell className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
        </button>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg transition"
        >
          {theme === 'light' ? (
            <Moon className="w-5 h-5 text-gray-600" />
          ) : (
            <Sun className="w-5 h-5 text-yellow-400" />
          )}
        </button>

        {/* User Avatar */}
        <button className="w-9 h-9 bg-gradient-to-br from-slate-400 to-slate-600 dark:from-slate-500 dark:to-slate-700 rounded-full flex items-center justify-center hover:opacity-90 transition">
          <User className="w-5 h-5 text-white" />
        </button>
      </div>
    </header>
  )
}
