'use client'

import { Download, Share2, Circle } from 'lucide-react'

export function ProgressCharts() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      {/* Weekly Progress */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-gray-200 dark:border-slate-700">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Weekly progress
          </h3>
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg transition">
            <Share2 className="w-4 h-4 text-gray-600 dark:text-gray-400" />
          </button>
        </div>

        {/* Categories */}
        <div className="flex gap-4 mb-6">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 bg-purple-500 rounded-full" />
            <span className="text-sm text-gray-600 dark:text-gray-400">Sport</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 bg-blue-500 rounded-full" />
            <span className="text-sm text-gray-600 dark:text-gray-400">Study</span>
          </div>
        </div>

        {/* Chart (SVG) */}
        <div className="h-32 mb-6">
          <svg viewBox="0 0 300 120" className="w-full h-full">
            {/* Grid lines */}
            <line x1="0" y1="100" x2="300" y2="100" stroke="#e5e7eb" strokeWidth="1" className="dark:stroke-slate-700" />

            {/* Wave line for weekly */}
            <path
              d="M 10 80 Q 40 60 70 70 T 130 50 T 190 75 T 250 55 T 290 70"
              stroke="#3b82f6"
              strokeWidth="2"
              fill="none"
            />
          </svg>
        </div>

        {/* Days */}
        <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
          <span>M</span>
          <span>T</span>
          <span>W</span>
          <span>T</span>
          <span>F</span>
          <span>S</span>
          <span>S</span>
        </div>
      </div>

      {/* Monthly Progress */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-gray-200 dark:border-slate-700">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Month progress
          </h3>
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg transition">
            <Download className="w-4 h-4 text-gray-600 dark:text-gray-400" />
          </button>
        </div>

        {/* Items */}
        <div className="space-y-4 mb-6">
          {[
            { label: 'Sport', percentage: 75, color: 'from-purple-500 to-pink-500' },
            { label: 'Body', percentage: 80, color: 'from-blue-500 to-cyan-500' },
            { label: 'Project', percentage: 45, color: 'from-green-500 to-emerald-500' },
          ].map((item, idx) => (
            <div key={idx}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-700 dark:text-gray-300">{item.label}</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">
                  {item.percentage}%
                </span>
              </div>
              <div className="w-full h-2 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
                <div
                  className={`h-full bg-gradient-to-r ${item.color}`}
                  style={{ width: `${item.percentage}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Circular Progress */}
        <div className="flex items-center justify-center mb-6">
          <div className="relative w-32 h-32">
            <svg viewBox="0 0 100 100" className="w-full h-full">
              {/* Background circle */}
              <circle
                cx="50"
                cy="50"
                r="40"
                fill="none"
                stroke="#e5e7eb"
                strokeWidth="3"
                className="dark:stroke-slate-700"
              />
              {/* Progress circle */}
              <circle
                cx="50"
                cy="50"
                r="40"
                fill="none"
                stroke="#3b82f6"
                strokeWidth="3"
                strokeDasharray="251.2"
                strokeDashoffset="62.8"
                strokeLinecap="round"
                transform="rotate(-90 50 50)"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="text-2xl font-bold text-gray-900 dark:text-white">120%</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">completed</div>
            </div>
          </div>
        </div>

        {/* Download Button */}
        <button className="w-full bg-gray-900 dark:bg-slate-800 text-white py-2 rounded-lg hover:bg-gray-800 dark:hover:bg-slate-700 transition flex items-center justify-center gap-2 text-sm font-medium">
          <Download className="w-4 h-4" />
          Download Report
        </button>
      </div>
    </div>
  )
}
