'use client'

import { Moon, RefreshCw, CheckCircle } from 'lucide-react'

export function LastProjects() {
  const projects = [
    {
      title: 'New Schedule',
      status: 'In progress',
      icon: Moon,
      description: 'Dairon preparing a new plan for Allure. Deliver in Friday 8 New Illustration. Job...',
      color: 'from-slate-400 to-slate-600',
      textColor: 'text-slate-700 dark:text-slate-300',
    },
    {
      title: 'Prototype animation',
      status: 'Completed',
      icon: RefreshCw,
      description: '',
      color: 'from-slate-500 to-slate-700',
      textColor: 'text-white',
    },
    {
      title: 'AI Project 2 part',
      status: 'In progress',
      icon: CheckCircle,
      description: '',
      color: 'from-slate-600 to-slate-800',
      textColor: 'text-white',
    },
  ]

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Last Projects
        </h3>
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg transition">
            <span className="text-sm text-gray-600 dark:text-gray-400">Sort by</span>
          </button>
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg transition">
            <svg
              className="w-4 h-4 text-gray-600 dark:text-gray-400"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <rect x="3" y="3" width="7" height="7" />
              <rect x="14" y="3" width="7" height="7" />
              <rect x="14" y="14" width="7" height="7" />
              <rect x="3" y="14" width="7" height="7" />
            </svg>
          </button>
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg transition">
            <svg
              className="w-4 h-4 text-gray-600 dark:text-gray-400"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <line x1="3" y1="6" x2="21" y2="6" stroke="currentColor" strokeWidth="2" />
              <line x1="3" y1="12" x2="21" y2="12" stroke="currentColor" strokeWidth="2" />
              <line x1="3" y1="18" x2="21" y2="18" stroke="currentColor" strokeWidth="2" />
            </svg>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project, idx) => {
          const Icon = project.icon
          return (
            <div
              key={idx}
              className={`bg-gradient-to-br ${project.color} rounded-2xl p-6 text-white hover:shadow-lg transition cursor-pointer group`}
            >
              <div className="flex items-start justify-between mb-4">
                <Icon className="w-6 h-6 opacity-70 group-hover:opacity-100 transition" />
                <span className="text-xs font-semibold px-3 py-1 bg-white/20 rounded-full">
                  {project.status}
                </span>
              </div>

              <h4 className="text-lg font-semibold mb-2">{project.title}</h4>

              {project.description && (
                <p className="text-sm opacity-90 mb-4">{project.description}</p>
              )}

              {!project.description && (
                <p className="text-sm opacity-70 mb-4">In progress</p>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
