'use client'

import { Sidebar } from './Sidebar'
import { Header } from './Header'
import { OverallInfoCard } from './OverallInfoCard'
import { ProgressCharts } from './ProgressCharts'
import { TaskSections } from './TaskSections'
import { LastProjects } from './LastProjects'

export function DashboardContent() {
  return (
    <div className="flex h-screen bg-gray-50 dark:bg-slate-950">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <Header />

        {/* Scrollable Content */}
        <main className="flex-1 overflow-auto">
          <div className="max-w-7xl mx-auto p-8">
            {/* Overall Info Card */}
            <OverallInfoCard />

            {/* Progress Charts */}
            <ProgressCharts />

            {/* Task Sections */}
            <TaskSections />

            {/* Last Projects */}
            <LastProjects />
          </div>
        </main>
      </div>
    </div>
  )
}
